#pragma warning(disable:4996)
#include <stdio.h>
#include <stdlib.h>
#include <Windows.h>
#include <math.h>

void RGB2YCbCr(BYTE* Color, BYTE* Y, BYTE* Cb, BYTE* Cr, int W, int H) {
	int temp;
	for (int i = 0; i < H; i++) {
		for (int j = 0; j < W; j++) {
			temp = i * W + j;
			Y[temp] = (BYTE)(0.299 * (float)Color[temp * 3 + 2] + 0.587 * (float)Color[temp * 3 + 1] + 0.114 * (float)Color[temp * 3]);
			Cb[temp] = (BYTE)((-0.16874 * (float)Color[temp * 3 + 2]) + (-0.3313 * (float)Color[temp * 3 + 1]) + (0.500 * (float)Color[temp * 3]) + 128);
			Cr[temp]= (BYTE)((0.500 * (float)Color[temp * 3 + 2]) + (-0.4187 * (float)Color[temp * 3 + 1]) + (-0.0813 * (float)Color[temp * 3]) + 128);
		}
	}
}

// ������� �������
void AverageConv(BYTE* Img, BYTE* Out, int W, int H)
{
	double Kernel[3][3] = { 0.11111, 0.11111, 0.11111,
							0.11111, 0.11111, 0.11111,
							0.11111, 0.11111, 0.11111 };
	double SumProduct = 0.0;					// ������� ��� ������ ���� ����

	for (int i = 1; i < H - 1; i++)				// Y��ǥ(��), ���� �����Ͽ� 1 ����
	{
		for (int j = 1; j < W - 1; j++)			// X��ǥ(��)
		{
			for (int m = -1; m <= 1; m++)		// Ŀ���� ��, [i][j] �߽����� 9ĭ ��ȸ
			{
				for (int n = -1; n <= 1; n++)	// Ŀ���� ��
				{
					SumProduct += Img[(i + m) * W + (j + n)] * Kernel[m + 1][n + 1];	// -1 ~ 1 ���� �����Ͽ� +1

				}
			}
			Out[i * W + j] = (BYTE)SumProduct;
			SumProduct = 0.0;
		}
	}
}

void YCbCr2RGB(BYTE* Y, BYTE* Cb, BYTE* Cr, BYTE* Output, int W, int H) {
	int temp;
	for (int i = 0; i < H; i++) {
		for (int j = 0; j < W; j++) {
			temp = i * W + j;
			Output[temp * 3] = (BYTE)((1.0 * (float)Y[temp]) + (1.772 * ((float)Cb[temp] - 128.0)));	// B
			Output[temp * 3 + 1] = (BYTE)((1.0 * (float)Y[temp]) + (-0.34414 * ((float)Cb[temp] - 128.0)) + (-0.71414 * ((float)Cr[temp] - 128.0))); 	// G
			Output[temp * 3 + 2] = (BYTE)((1.0 * (float)Y[temp]) + (1.402 * ((float)Cr[temp] - 128.0)));	// R
		}
	}
}

void DrawCross(BYTE * In, int W, int H, int Cx, int Cy, int R, int G, int B)
{
	for (int i = 0; i < W; i++){
		In[(Cy * W + i) * 3] = B;
		In[(Cy * W + i) * 3 + 1] = G;
		In[(Cy * W + i) * 3 + 2] = R;
	}
	for (int i = 0; i < H; i++){
		In[(i * W + Cx) * 3] = B;
		In[(i * W + Cx) * 3 + 1] = G;
		In[(i * W + Cx) * 3 + 2] = R;
	}
}

int main()
{
	BITMAPFILEHEADER hf;
	BITMAPINFOHEADER hInfo;
	RGBQUAD hRGB[256];
	FILE * fp;
	fp = fopen("lenna_rgb.bmp", "rb");
	if (fp == NULL)
	{
		printf("File not found!\n");
		return 0;
	}

	fread(&hf, sizeof(BITMAPFILEHEADER), 1, fp);
	fread(&hInfo, sizeof(BITMAPINFOHEADER), 1, fp);
	if (hInfo.biBitCount == 8) // Index(Gray) Image �� �ȷ�Ʈ �о����
		fread(hRGB, sizeof(RGBQUAD), 256, fp);

	int W, H, ImgSize;
	W = hInfo.biWidth;
	H = hInfo.biHeight;
	ImgSize = W*H;
	BYTE * Image;
	BYTE * Output;
	if (hInfo.biBitCount == 8){
		Image = (BYTE *)malloc(ImgSize);
		Output = (BYTE *)malloc(ImgSize);
		fread(Image, sizeof(BYTE), ImgSize, fp);
	}
	else if (hInfo.biBitCount == 24){
		Image = (BYTE *)malloc(ImgSize * 3);
		Output = (BYTE *)malloc(ImgSize * 3);
		fread(Image, sizeof(BYTE), ImgSize * 3, fp);
	}
	else
	{
		printf("Memory not allocated!\n");
		return 0;
	}
	fclose(fp);

	BYTE * Y = (BYTE *)malloc(ImgSize);
	BYTE* Cb = (BYTE*)malloc(ImgSize);
	BYTE* Cr = (BYTE*)malloc(ImgSize);
	BYTE* Temp = (BYTE*)malloc(ImgSize);

	// ������ YCbCr�� ��ȯ
	RGB2YCbCr(Image, Y, Cb, Cr, W, H);
	// Y ���п� ���� 3 * 3 ������� ��������� ����
	AverageConv(Y, Temp, W, H);
	// �ٽ� RGB ������ BMP �������� ���
	YCbCr2RGB(Temp, Cb, Cr, Output, W, H);


	// ����� ���Ϸ� ���
	fp = fopen("lenna_output.bmp", "wb");
	fwrite(&hf, sizeof(BYTE), sizeof(BITMAPFILEHEADER), fp);
	fwrite(&hInfo, sizeof(BYTE), sizeof(BITMAPINFOHEADER), fp);
	if (hInfo.biBitCount == 8)
		fwrite(hRGB, sizeof(RGBQUAD), 256, fp);
	if (hInfo.biBitCount == 8)
		fwrite(Output, sizeof(BYTE), ImgSize, fp);
	else if (hInfo.biBitCount == 24)
		fwrite(Output, sizeof(BYTE), ImgSize*3, fp);
	
	fclose(fp);
	free(Image);
	free(Output);
	free(Y);
	free(Cb);
	free(Cr);

	return 0;
}